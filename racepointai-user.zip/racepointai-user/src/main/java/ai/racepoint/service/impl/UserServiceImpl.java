package ai.racepoint.service.impl;

import ai.racepoint.exception.userexception.UserNotFoundException;
import ai.racepoint.exception.userexception.UserAlreadyExistsException;
import ai.racepoint.exception.userexception.InvalidUserDataException;
import ai.racepoint.model.User;
import ai.racepoint.repository.UserRepository;
import ai.racepoint.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public User getUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException("User with ID " + id + " not found."));
    }

    @Override
    public User createUser(User user) {
        if (userRepository.existsByEmail(user.getEmail())) {
            throw new UserAlreadyExistsException("User with email " + user.getEmail() + " already exists.");
        }
        if (!isValidUser(user)) {
            throw new InvalidUserDataException("Invalid user data provided.");
        }
        return userRepository.save(user);
    }

    @Override
    public User updateUser(Long id, User updatedUser) {
        return userRepository.findById(id)
                .map(user -> {
                    user.setFirstName(updatedUser.getFirstName());
                    user.setLastName(updatedUser.getLastName());
                    user.setEmail(updatedUser.getEmail());
                    user.setPhoneNumber(updatedUser.getPhoneNumber());
                    return userRepository.save(user);
                })
                .orElseThrow(() -> new UserNotFoundException("User with ID " + id + " not found."));
    }

    @Override
    public void deleteUser(Long id) {
        if (!userRepository.existsById(id)) {
            throw new UserNotFoundException("User with ID " + id + " not found.");
        }
        userRepository.deleteById(id);
    }

    private boolean isValidUser(User user) {
        return user.getFirstName() != null && user.getLastName() != null && user.getEmail() != null;
    }
}
