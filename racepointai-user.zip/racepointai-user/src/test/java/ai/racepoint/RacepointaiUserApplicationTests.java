package ai.racepoint;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RacepointaiUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
